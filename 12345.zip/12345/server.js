const express = require('express');
const app = express()
const port = 3000
const produtos = require("./produtos.json")
let usuarios =[
    {
        id:1,
        nome:"João"
    },
    {
        id:2,
        nome:"Julia"
    }
]
app.get("/produtos",(req,res)=>{
    res.send("Pagina de produtos")
})
app.get("/contatos",(req,res)=>{
    res.send("Pagina de contatos")
})
app.get('/usuarios', (req, res) => {
  res.send(usuarios)
})
app.get('/usuarios/:id', (req, res) => {
  const id = Number(req.params.id);
  const usuario = usuarios.find((item)=>{
    return item.id === id;
  })
  if(.length === 0){
    return res.status(404).json({mensagem:"Não encontrado"})
  }
  res.status(200).json(usuario);
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})